def search_prime(lower_bound: int, upper_bound: int) -> list:
    # Return any prime numbers found in the given range, where endpoints are included.
    mod6 = []
    found = []
    if lower_bound == 2 and upper_bound == 2:
        found.append(2)
    if lower_bound == 2 and upper_bound > 2:
        found.append(2)
        found.append(3)
    if lower_bound == 3:
        found.append(3)
    for n in range(lower_bound, upper_bound + 1):
        if n % 6 == 1 or n % 6 == 5:
            mod6.append(n)
    for num in mod6:
        for i in range(5, int(abs(num)**0.5) + 1, 6):
            if num % i == 0 or num % (i + 2) == 0:
                break
        else:
            found.append(num)
    return found
