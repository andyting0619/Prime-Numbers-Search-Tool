from setuptools import setup

setup(name='prime_number',
      version='1.0',
      description='prime number search tool',
      author_email='andyting0619@gmail.com',
      py_modules=['prime_number']
      )
